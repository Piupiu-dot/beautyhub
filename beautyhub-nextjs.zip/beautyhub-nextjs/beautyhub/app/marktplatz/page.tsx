'use client'
import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import AppShell from '@/components/AppShell'
import { supabase } from '@/lib/supabase'

const DEMO = [
  {id:'1',titel:'IPL Gerät Lumenis M22',beschreibung:'Wenig benutzt, alle Handtücher vorhanden. Serviciert 2024. Ideal für Haarentfernung und Gefässbehandlung.',preis:4800,kategorie:'geraete',zustand:'gebraucht',standort:'Zürich',verkaeuferin_id:'demo1'},
  {id:'2',titel:'Nagelfräser Dremel Professional Set',beschreibung:'Komplettes Set mit 12 Bits, kaum benutzt. Originalverpackung vorhanden.',preis:120,kategorie:'geraete',zustand:'neu',standort:'Bern',verkaeuferin_id:'demo2'},
  {id:'3',titel:'Profi-Kosmetikliege klappbar weiss',beschreibung:'Stabile Liege mit Memory-Foam Polster. 2 Jahre alt, sehr guter Zustand.',preis:350,kategorie:'mobel',zustand:'gebraucht',standort:'Basel',verkaeuferin_id:'demo3'},
  {id:'4',titel:'PMU Kurs Grundlagen',beschreibung:'2-tägiger Intensivkurs in Zürich. Theorie und Praxis, Material inklusive. Zertifikat wird ausgestellt.',preis:480,kategorie:'kurse',zustand:'neu',standort:'Zürich',verkaeuferin_id:'demo4'},
]
const KATS = ['alle','geraete','produkte','mobel','kurse','sonstiges']

export default function MarktplatzPage() {
  const router = useRouter()
  const [inserate, setInserate] = useState<any[]>(DEMO)
  const [kat, setKat] = useState('alle')
  const [av, setAv] = useState('M')
  const [detail, setDetail] = useState<any>(null)
  const [chatMode, setChatMode] = useState(false)
  const [chatMsg, setChatMsg] = useState('')
  const [chatHistory, setChatHistory] = useState<{von:'ich'|'sie',text:string}[]>([])
  const [user, setUser] = useState<any>(null)
  const [showForm, setShowForm] = useState(false)
  const [form, setForm] = useState({titel:'',beschreibung:'',preis:'',kategorie:'geraete',zustand:'gebraucht',standort:''})

  useEffect(() => {
    supabase.auth.getSession().then(({data}) => {
      if (!data.session) router.push('/login')
      else { const n=data.session.user.user_metadata?.name||data.session.user.email||'M'; setAv(n[0].toUpperCase()); setUser(data.session.user) }
    })
    supabase.from('inserate').select('*').eq('aktiv',true).order('erstellt_am',{ascending:false}).then(({data}) => { if (data?.length) setInserate(data) })
  }, [router])

  const filtered = kat==='alle' ? inserate : inserate.filter(i => i.kategorie===kat)
  const ic = 'w-full px-4 py-3 rounded-xl border-[1.5px] border-[#E8E0D5] bg-[#faf8f5] text-sm outline-none focus:border-[#b8924a]'

  function sendChat() {
    if (!chatMsg.trim()) return
    setChatHistory(h => [...h, {von:'ich',text:chatMsg}])
    setChatMsg('')
    setTimeout(() => setChatHistory(h => [...h, {von:'sie',text:'Danke für deine Nachricht! Ich melde mich bald.'}]), 800)
  }

  return (
    <AppShell>
      <div className="bg-white px-4 py-4 flex items-center justify-between border-b border-[#F0EAE0] sticky top-0 z-40">
        <h1 className="font-serif text-2xl font-bold text-[#1A1A2E]">Marktplatz</h1>
        <div className="flex items-center gap-2">
          <button onClick={() => setShowForm(true)} className="bg-[#b8924a] text-white text-xs font-medium px-3 py-2 rounded-xl">+ Inserieren</button>
          <button onClick={() => router.push('/profil')} className="w-9 h-9 rounded-full bg-[#b8924a] flex items-center justify-center text-white text-sm font-semibold">{av}</button>
        </div>
      </div>
      <div className="bg-white border-b border-[#F0EAE0] px-4 py-3 overflow-x-auto no-scrollbar">
        <div className="flex gap-2 whitespace-nowrap">
          {KATS.map(k => (<button key={k} onClick={() => setKat(k)} className={`px-4 py-2 rounded-full text-xs font-medium border-[1.5px] flex-shrink-0 transition-all ${kat===k?'bg-[#1A1A2E] text-white border-[#1A1A2E]':'bg-white text-[#6B6B6B] border-[#E8E0D5]'}`}>{k==='alle'?'Alle':k.charAt(0).toUpperCase()+k.slice(1)}</button>))}
        </div>
      </div>
      <div className="p-4 grid grid-cols-2 gap-3">
        {filtered.map(ins => (
          <div key={ins.id} onClick={() => { setDetail(ins); setChatMode(false); setChatHistory([]) }}
            className="bg-white rounded-2xl overflow-hidden shadow-sm hover:-translate-y-0.5 hover:shadow-md transition-all cursor-pointer">
            <div className="h-28 bg-[#F5EFE8] flex items-center justify-center relative">
              <svg width="36" height="36" viewBox="0 0 50 50" fill="none"><rect x="8" y="12" width="34" height="26" rx="4" stroke="#8a7055" strokeWidth="1.5"/><path d="M8 20h34" stroke="#8a7055" strokeWidth="1.5"/><circle cx="16" cy="16" r="2" stroke="#8a7055" strokeWidth="1.2"/></svg>
              <span className={`absolute top-2 left-2 text-[10px] font-bold px-2 py-0.5 rounded-lg ${ins.zustand==='neu'?'bg-[#E8F5E9] text-[#2E7D32]':'bg-[#FFF3E0] text-[#E65100]'}`}>{ins.zustand==='neu'?'Neu':'Gebraucht'}</span>
            </div>
            <div className="p-3">
              <p className="text-sm font-semibold text-[#1A1A2E] line-clamp-2 mb-1 leading-tight">{ins.titel}</p>
              <p className="font-serif text-lg font-bold text-[#b8924a]">CHF {Number(ins.preis).toLocaleString('de-CH')}</p>
              <p className="text-xs text-[#9A9A9A]">{ins.standort}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Detail Modal */}
      {detail && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-end justify-center p-0" onClick={e => { if(e.target===e.currentTarget){setDetail(null);setChatMode(false)} }}>
          <div className="bg-white rounded-t-3xl w-full max-w-xl max-h-[85vh] flex flex-col">
            {!chatMode ? (
              <div className="overflow-y-auto">
                <div className="p-5 pb-2">
                  <div className="w-12 h-1 bg-[#E0D8D0] rounded-full mx-auto mb-4"/>
                  <div className="h-40 bg-[#F5EFE8] rounded-2xl flex items-center justify-center mb-4">
                    <svg width="50" height="50" viewBox="0 0 50 50" fill="none"><rect x="8" y="12" width="34" height="26" rx="4" stroke="#8a7055" strokeWidth="1.5"/><path d="M8 20h34" stroke="#8a7055" strokeWidth="1.5"/><circle cx="16" cy="16" r="2" stroke="#8a7055" strokeWidth="1.2"/></svg>
                  </div>
                  <h2 className="font-serif text-xl font-bold text-[#1A1A2E] mb-1">{detail.titel}</h2>
                  <p className="font-serif text-3xl font-bold text-[#b8924a] mb-3">CHF {Number(detail.preis).toLocaleString('de-CH')}</p>
                  <div className="flex gap-2 flex-wrap mb-3">
                    {detail.kategorie && <span className="text-xs bg-[#F5EFE8] text-[#6B6B6B] px-3 py-1 rounded-full">{detail.kategorie}</span>}
                    <span className={`text-xs px-3 py-1 rounded-full ${detail.zustand==='neu'?'bg-[#E8F5E9] text-[#2E7D32]':'bg-[#FFF3E0] text-[#E65100]'}`}>{detail.zustand==='neu'?'Neu':'Gebraucht'}</span>
                    {detail.standort && <span className="text-xs bg-[#F5EFE8] text-[#6B6B6B] px-3 py-1 rounded-full">📍 {detail.standort}</span>}
                  </div>
                  <p className="text-sm text-[#5A5A5A] leading-relaxed mb-4">{detail.beschreibung}</p>
                </div>
                <div className="px-5 pb-6 space-y-2">
                  <button onClick={() => setChatMode(true)} className="w-full py-4 bg-[#b8924a] text-white rounded-xl font-medium flex items-center justify-center gap-2">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2}><path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z"/></svg>
                    Verkäuferin kontaktieren
                  </button>
                  <button onClick={() => setDetail(null)} className="w-full py-3 rounded-xl border-[1.5px] border-[#E8E0D5] text-[#6B6B6B] text-sm">Schliessen</button>
                </div>
              </div>
            ) : (
              <div className="flex flex-col h-full min-h-0">
                <div className="p-4 border-b border-[#F0EAE0] flex items-center gap-3">
                  <button onClick={() => setChatMode(false)} className="text-[#b8924a]">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2.5}><polyline points="15 18 9 12 15 6"/></svg>
                  </button>
                  <div className="w-8 h-8 rounded-full bg-[#E8DDD0] flex items-center justify-center text-[#b8924a] font-bold text-sm">V</div>
                  <div>
                    <p className="text-sm font-semibold text-[#1A1A2E]">Verkäuferin</p>
                    <p className="text-xs text-[#9A9A9A] truncate max-w-[180px]">{detail.titel}</p>
                  </div>
                </div>
                <div className="flex-1 overflow-y-auto p-4 space-y-3 min-h-0">
                  {chatHistory.length === 0 && (
                    <p className="text-center text-xs text-[#9A9A9A] py-4">Schreibe deine erste Nachricht zur Verkäuferin</p>
                  )}
                  {chatHistory.map((m, i) => (
                    <div key={i} className={`flex ${m.von==='ich' ? 'justify-end' : 'justify-start'}`}>
                      <div className={`max-w-[75%] px-4 py-2.5 rounded-2xl text-sm ${m.von==='ich' ? 'bg-[#b8924a] text-white rounded-br-sm' : 'bg-white text-[#1A1A2E] shadow-sm rounded-bl-sm'}`}>{m.text}</div>
                    </div>
                  ))}
                </div>
                <div className="p-4 border-t border-[#F0EAE0] flex gap-2">
                  <input value={chatMsg} onChange={e=>setChatMsg(e.target.value)} onKeyDown={e=>e.key==='Enter'&&sendChat()}
                    placeholder="Nachricht schreiben..." className="flex-1 px-4 py-3 rounded-xl border-[1.5px] border-[#E8E0D5] bg-[#faf8f5] text-sm outline-none focus:border-[#b8924a] min-w-0"/>
                  <button onClick={sendChat} className="w-11 h-11 bg-[#b8924a] rounded-xl flex items-center justify-center flex-shrink-0">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth={2}><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Inserat erstellen */}
      {showForm && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-end justify-center" onClick={e=>{if(e.target===e.currentTarget)setShowForm(false)}}>
          <div className="bg-white rounded-t-3xl w-full max-w-xl p-6 pb-8 max-h-[90vh] overflow-y-auto">
            <div className="w-12 h-1 bg-[#E0D8D0] rounded-full mx-auto mb-5"/>
            <h2 className="font-serif text-xl font-bold text-[#1A1A2E] mb-5">Inserat erstellen</h2>
            <div className="space-y-3">
              <div><label className="block text-[11px] font-medium text-[#6B6B6B] uppercase tracking-wider mb-1.5">Titel</label><input className={ic} value={form.titel} onChange={e=>setForm({...form,titel:e.target.value})} placeholder="z.B. IPL Gerät Lumenis"/></div>
              <div><label className="block text-[11px] font-medium text-[#6B6B6B] uppercase tracking-wider mb-1.5">Beschreibung</label><textarea className={ic+' resize-none h-20'} value={form.beschreibung} onChange={e=>setForm({...form,beschreibung:e.target.value})}/></div>
              <div className="grid grid-cols-2 gap-3">
                <div><label className="block text-[11px] font-medium text-[#6B6B6B] uppercase tracking-wider mb-1.5">Preis (CHF)</label><input type="number" className={ic} value={form.preis} onChange={e=>setForm({...form,preis:e.target.value})} placeholder="0"/></div>
                <div><label className="block text-[11px] font-medium text-[#6B6B6B] uppercase tracking-wider mb-1.5">Standort</label><input className={ic} value={form.standort} onChange={e=>setForm({...form,standort:e.target.value})} placeholder="z.B. Zürich"/></div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div><label className="block text-[11px] font-medium text-[#6B6B6B] uppercase tracking-wider mb-1.5">Kategorie</label>
                  <select className={ic} value={form.kategorie} onChange={e=>setForm({...form,kategorie:e.target.value})}>
                    <option value="geraete">Geräte</option><option value="produkte">Produkte</option><option value="mobel">Möbel</option><option value="kurse">Kurse</option><option value="sonstiges">Sonstiges</option>
                  </select></div>
                <div><label className="block text-[11px] font-medium text-[#6B6B6B] uppercase tracking-wider mb-1.5">Zustand</label>
                  <select className={ic} value={form.zustand} onChange={e=>setForm({...form,zustand:e.target.value})}>
                    <option value="neu">Neu</option><option value="gebraucht">Gebraucht</option>
                  </select></div>
              </div>
            </div>
            <div className="flex gap-2 mt-5">
              <button onClick={() => setShowForm(false)} className="flex-1 py-3 rounded-xl border-[1.5px] border-[#E8E0D5] text-[#6B6B6B] text-sm">Abbrechen</button>
              <button onClick={async () => { if(!user||!form.titel||!form.preis) return; await supabase.from('inserate').insert({...form,preis:parseFloat(form.preis),verkaeuferin_id:user.id,aktiv:true}); setShowForm(false); }} className="flex-[2] py-3 rounded-xl bg-[#b8924a] text-white text-sm font-medium">Veröffentlichen</button>
            </div>
          </div>
        </div>
      )}
    </AppShell>
  )
}
