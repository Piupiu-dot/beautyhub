'use client'
import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import AppShell from '@/components/AppShell'
import { supabase, Post } from '@/lib/supabase'

const NISCHEN = ['alle','laser','gesicht','nagel','pmu','wimpern','haar','med']

const DEMO: Post[] = [
  { id: 'c1', titel: 'Wer hat Erfahrung mit dem Nd:YAG Laser für dunkle Hauttypen?', inhalt: 'Ich suche Kolleginnen die bereits Erfahrung mit dem Nd:YAG 1064nm bei Hauttyp IV-V haben. Welche Parameter verwendet ihr für die Haarentfernung?', typ: 'community', nischen: 'laser', autor_name: 'Sophie K.', erstellt_am: new Date(Date.now()-7200000).toISOString(), likes: 12, kommentare_count: 5 },
  { id: 'c2', titel: 'Empfehlung für PMU-Pigmente die REACH-konform sind?', inhalt: 'Nach den neuen EU-Richtlinien suche ich nach REACH-konformen Pigmenten für Augenbrauen PMU.', typ: 'community', nischen: 'pmu', autor_name: 'Lena M.', erstellt_am: new Date(Date.now()-14400000).toISOString(), likes: 8, kommentare_count: 11 },
  { id: 'c3', titel: 'Tipps gegen Hebelifting bei sehr feinen Haaren?', inhalt: 'Ich habe Kundinnen mit extrem feinen Haaren bei denen das Wimpernlifting schnell durchhängt.', typ: 'community', nischen: 'wimpern', autor_name: 'Nina B.', erstellt_am: new Date(Date.now()-28800000).toISOString(), likes: 19, kommentare_count: 7 },
  { id: 'c4', titel: 'Gel-Allergien nehmen zu - eure Erfahrungen?', inhalt: 'Ich beobachte seit einigen Monaten vermehrt Kontaktallergien bei Gelnaegeln.', typ: 'community', nischen: 'nagel', autor_name: 'Tanja R.', erstellt_am: new Date(Date.now()-50000000).toISOString(), likes: 31, kommentare_count: 14 },
]

function timeAgo(d: string) {
  const h = Math.floor((Date.now() - new Date(d).getTime()) / 3600000)
  if (h < 1) return 'Gerade eben'
  if (h < 24) return `vor ${h}h`
  return `vor ${Math.floor(h/24)} Tagen`
}

export default function CommunityPage() {
  const router = useRouter()
  const [posts, setPosts] = useState<Post[]>([])
  const [nische, setNische] = useState('alle')
  const [loading, setLoading] = useState(true)
  const [showModal, setShowModal] = useState(false)
  const [text, setText] = useState('')
  const [selN, setSelN] = useState<string[]>([])
  const [user, setUser] = useState<any>(null)
  const [avatar, setAvatar] = useState('M')

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      if (!data.session) router.push('/login')
      else { const n = data.session.user.user_metadata?.name || data.session.user.email || 'M'; setAvatar(n[0].toUpperCase()); setUser(data.session.user) }
    })
  }, [router])

  useEffect(() => { loadPosts() }, [nische])

  async function loadPosts() {
    setLoading(true)
    try {
      let q = supabase.from('posts').select('*').eq('typ', 'community').order('erstellt_am', { ascending: false }).limit(20)
      if (nische !== 'alle') q = q.ilike('nischen', `%${nische}%`)
      const { data, error } = await q
      setPosts(error || !data?.length ? DEMO.filter(p => nische === 'alle' || p.nischen?.includes(nische)) : data)
    } catch { setPosts(DEMO) }
    setLoading(false)
  }

  async function submitPost() {
    if (!text.trim() || !user) return
    const { error } = await supabase.from('posts').insert({ titel: text.substring(0, 80), inhalt: text, typ: 'community', nischen: selN.join(','), autor_id: user.id, autor_name: user.user_metadata?.name || user.email, ist_agent: false, likes: 0 })
    if (!error) { setShowModal(false); setText(''); setSelN([]); loadPosts() }
  }

  const toggleN = (n: string) => setSelN(prev => prev.includes(n) ? prev.filter(x => x !== n) : [...prev, n])

  return (
    <AppShell>
      <div className="bg-white px-5 py-4 flex items-center justify-between border-b border-[#F0EAE0] sticky top-0 z-40">
        <h1 className="font-serif text-2xl font-bold text-[#1A1A2E]">Community</h1>
        <button onClick={() => router.push('/profil')} className="w-9 h-9 rounded-full bg-[#b8924a] flex items-center justify-center text-white text-sm font-semibold">{avatar}</button>
      </div>

      {/* Compose */}
      <div className="m-4 bg-white rounded-2xl p-4 shadow-sm flex items-center gap-3">
        <div className="w-10 h-10 rounded-full bg-[#b8924a] flex items-center justify-center text-white font-semibold flex-shrink-0">{avatar}</div>
        <div onClick={() => setShowModal(true)} className="flex-1 bg-[#faf8f5] border-[1.5px] border-[#E8E0D5] rounded-xl px-4 py-3 text-sm text-[#9A9A9A] cursor-pointer">Frage stellen oder Erfahrung teilen...</div>
        <button onClick={() => setShowModal(true)} className="bg-[#b8924a] text-white text-sm font-medium px-4 py-2.5 rounded-xl flex-shrink-0">Posten</button>
      </div>

      {/* Filter */}
      <div className="px-4 pb-3.5 overflow-x-auto no-scrollbar">
        <div className="flex gap-2 whitespace-nowrap">
          {NISCHEN.map(n => (
            <button key={n} onClick={() => setNische(n)}
              className={`px-4 py-2 rounded-full text-xs font-medium border-[1.5px] transition-all
                ${nische === n ? 'bg-[#1A1A2E] text-white border-[#1A1A2E]' : 'bg-white text-[#6B6B6B] border-[#E8E0D5]'}`}>
              {n === 'alle' ? 'Alle' : n.charAt(0).toUpperCase() + n.slice(1)}
            </button>
          ))}
        </div>
      </div>

      {/* Posts */}
      <div className="px-4 grid gap-3 sm:grid-cols-2">
        {loading ? <><div className="skeleton h-40"/><div className="skeleton h-40"/></> : posts.map(p => (
          <Link key={p.id} href={`/feed/${p.id}`}
            className="block bg-white rounded-2xl p-5 shadow-sm hover:-translate-y-0.5 hover:shadow-md transition-all cursor-pointer">
            <div className="flex items-center gap-2.5 mb-3">
              <div className="w-9 h-9 rounded-full bg-[#E8DDD0] flex items-center justify-center text-[#b8924a] font-bold text-sm">{(p.autor_name||'?')[0].toUpperCase()}</div>
              <div>
                <p className="text-sm font-semibold text-[#1A1A2E]">{p.autor_name || 'Anonym'}{p.nischen && <span className="ml-2 text-[11px] text-[#b8924a] bg-[#FFF8F0] px-2 py-0.5 rounded-full">{p.nischen.split(',')[0]}</span>}</p>
                <p className="text-xs text-[#9A9A9A]">{p.erstellt_am ? timeAgo(p.erstellt_am) : ''}</p>
              </div>
            </div>
            <h3 className="font-serif text-lg font-semibold text-[#1A1A2E] leading-snug mb-2">{p.titel}</h3>
            <p className="text-sm text-[#5A5A5A] leading-relaxed line-clamp-3">{p.inhalt}</p>
            <div className="flex items-center gap-4 mt-3 pt-3 border-t border-[#F5F0EA]">
              <span className="flex items-center gap-1 text-xs text-[#9A9A9A]"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8}><path d="M20.84 4.61a5.5 5.5 0 00-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 00-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 000-7.78z"/></svg>{p.likes||0}</span>
              <span className="flex items-center gap-1 text-xs text-[#9A9A9A]"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8}><path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z"/></svg>{p.kommentare_count||0} Antworten</span>
              <span className="ml-auto text-xs text-[#b8924a] font-semibold">Lesen →</span>
            </div>
          </Link>
        ))}
      </div>

      {/* Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-end justify-center" onClick={e => { if (e.target === e.currentTarget) setShowModal(false) }}>
          <div className="bg-white rounded-t-3xl w-full max-w-xl p-6 pb-10">
            <h2 className="font-serif text-xl font-bold text-[#1A1A2E] mb-4">Neuer Beitrag</h2>
            <textarea value={text} onChange={e => setText(e.target.value)} placeholder="Was möchtest du teilen?" rows={4}
              className="w-full border-[1.5px] border-[#E8E0D5] rounded-xl px-4 py-3 text-sm bg-[#faf8f5] outline-none focus:border-[#b8924a] focus:bg-white resize-none"/>
            <div className="flex gap-2 flex-wrap my-3">
              {NISCHEN.filter(n => n !== 'alle').map(n => (
                <button key={n} onClick={() => toggleN(n)}
                  className={`px-3 py-1.5 rounded-full text-xs border-[1.5px] transition-all ${selN.includes(n) ? 'bg-[#1A1A2E] text-white border-[#1A1A2E]' : 'bg-white text-[#6B6B6B] border-[#E8E0D5]'}`}>
                  {n}
                </button>
              ))}
            </div>
            <div className="flex gap-2 mt-2">
              <button onClick={() => setShowModal(false)} className="flex-1 py-3 rounded-xl border-[1.5px] border-[#E8E0D5] text-[#6B6B6B] text-sm">Abbrechen</button>
              <button onClick={submitPost} className="flex-[2] py-3 rounded-xl bg-[#b8924a] text-white text-sm font-medium">Veröffentlichen</button>
            </div>
          </div>
        </div>
      )}
    </AppShell>
  )
}
